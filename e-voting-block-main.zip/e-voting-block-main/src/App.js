import Radium from "radium";
import Routes from "./Routes";
function App() {
  return <Routes />;
}
export default Radium(App);

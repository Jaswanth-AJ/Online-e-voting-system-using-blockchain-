#Block chain based voting system

<img width="938" alt="10" src="https://user-images.githubusercontent.com/65611955/161438046-93fe6e4d-8a26-4f76-811a-54b4537f81a7.png">
<img width="939" alt="11" src="https://user-images.githubusercontent.com/65611955/161438051-f497d008-7267-46bc-bfba-55371019014c.png">
<img  src="https://user-images.githubusercontent.com/65611955/161437687-c313362f-8e12-4485-843f-10718c5117c7.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437699-5be02a82-4161-443a-b012-7f80b0cb2fe1.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437707-04cd44d1-0430-4b4c-adb1-c66aab6a9665.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437715-ffc9c0a1-3c52-4ecd-9be3-d1dd6155edf9.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437718-2dd36df0-1f95-4f72-8639-2c12cf198ccc.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437728-ff3cc890-a021-42c7-94ba-fa9bb4f7069b.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437738-a97bd83d-f5ce-4210-9d15-57715521f7fd.jpeg"/>
<img src="https://user-images.githubusercontent.com/65611955/161437745-2c1b70d1-e38b-4c7b-bf85-fef29be2a42a.jpeg"/>

